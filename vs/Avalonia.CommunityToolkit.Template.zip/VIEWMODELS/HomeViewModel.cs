﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace $safeprojectname$.ViewModels
{
    public partial class HomeViewModel : ViewModelBase
    {
        [ObservableProperty]
        private string _greeting = "Hello, World!";
    }
}
