﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace $safeprojectname$.ViewModels
{
    public partial class MainWindowViewModel : ViewModelBase
    {
        [ObservableProperty]
        private ViewModelBase _currentViewModel = new HomeViewModel();
    }
}
