﻿using Avalonia.Controls;

namespace $safeprojectname$.Views
{
    public partial class HomeView : UserControl
    {
        public HomeView()
        {
            InitializeComponent();
        }
    }
}