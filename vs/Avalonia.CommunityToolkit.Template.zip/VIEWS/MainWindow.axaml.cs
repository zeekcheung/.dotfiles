﻿using Avalonia.Controls;

namespace $safeprojectname$.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}