﻿using Avalonia.Controls;
using Avalonia.Controls.Templates;
using CommunityToolkit.Mvvm.ComponentModel;
using System;

namespace $safeprojectname$
{
    public class ViewLocator : IDataTemplate
    {
        /// <summary>
        /// 根据 ViewModel 的类型创建对应的 View
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public Control? Build(object? param)
        {
            if (param is null)
            {
                return null;
            }

            // 获取 ViewModel 的完全限定名
            string? viewModelFullName = param.GetType().FullName;

            // 获取 View 的完全限定名（/ViewModels/MainViewModel -> /Views/MainView）
            string viewFullName = viewModelFullName!.Replace("ViewModel", "View", StringComparison.Ordinal);

            // 获取 View 的类型
            Type? viewType = Type.GetType(viewFullName);

            // 创建 View 的实例
            if (viewType != null)
            {
                return (Control)Activator.CreateInstance(viewType)!;
            }

            return new TextBlock { Text = $"View Not Found: {viewFullName}" };
        }

        /// <summary>
        /// 判断 ContentControl 的 Content 是否是 ViewModel
        /// </summary>
        /// <param name="data">Content</param>
        /// <returns>ContentControl 的 Content 是否是 ViewModel</returns>
        public bool Match(object? data)
        {
            return data is ObservableObject;
        }
    }
}
