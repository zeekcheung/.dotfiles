﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace $safeprojectname$.ViewModels
{
    public partial class MainWindowViewModel : ViewModelBase
    {
        [ObservableProperty]
        private ObservableObject _currentViewModel = new HomeViewModel();
    }
}
