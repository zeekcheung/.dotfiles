﻿
namespace $safeprojectname$.ViewModels
{
    public partial class HomeViewModel : ViewModelBase
    {
        public string Greeting => "Welcome to Avalonia!";
    }
}
