﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace $safeprojectname$.ViewModels
{
    public class ViewModelBase : ObservableObject
    {
    }
}
